import cv2
import os
import numpy as np
import skimage
import torch
import matplotlib.pyplot as plt
# from skimage.feature import greycomatrix, graycoprops
import warnings
warnings.filterwarnings("ignore")

# 泛洪填充
def flood_fill_improved(image, seed_point):
    h, w = image.shape[:2]
    mask = np.zeros((h + 2, w + 2), np.uint8)
    connectivity = 8
    # 调整泛洪填充的颜色范围
    a = 5
    lo_diff = (a, a, a)
    up_diff = (a, a, a)
    # new_value = (220, 220, 220)
    new_value = (255, 255, 255)
    cv2.floodFill(image, mask, seed_point, new_value, lo_diff, up_diff, connectivity)
    return image

# 自适应阈值分割
def adaptive_thresholding(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    return cv2.bitwise_and(image, image, mask=thresh)

# 9维颜色特征
def c_feature_9(image):
    features = []
    # 找到非白色像素的索引
    non_white_indices = np.where((image[:, :, 0] != 255) | (image[:, :, 1] != 255) | (image[:, :, 2] != 255))
    for channel in range(3):
        # 提取非白色像素的当前通道值
        non_white_pixels = image[non_white_indices][:, channel]
        mean = np.mean(non_white_pixels)
        std = np.std(non_white_pixels)
        skew = np.mean(np.power(non_white_pixels - mean, 3))
        features.extend([mean, std, skew])
    return features

# 30维颜色特征
def c_feature_30(image):
    features = []
    # 找到非白色像素的索引
    non_white_indices = np.where((image[:, :, 0] != 255) | (image[:, :, 1] != 255) | (image[:, :, 2] != 255))
    for channel in range(3):
        # 提取非白色像素的当前通道值
        non_white_pixels = image[non_white_indices][:, channel]
        # 计算直方图，将像素值范围[0, 255]分成10个区间
        hist, _ = np.histogram(non_white_pixels, bins=10, range=[0, 256])
        # 归一化直方图
        if hist.sum() != 0:
            hist = hist / hist.sum()
        features.extend(hist)
    return np.array(features)

# 颜色相似度矩阵
def s_mat_color(features1, features2):
    # 计算特征向量之间的距离矩阵
    n1 = len(features1)
    n2 = len(features2)
    s_matrix = np.zeros((n1, n2))  # 初始化距离矩阵为全0的numpy数组

    for i, f1 in enumerate(features1):
        for j, f2 in enumerate(features2):
            distance = np.sum(np.abs(f1 - f2))
            s_matrix[i, j] = distance

    # similarity = 1-s/3
    s_matrix = s_matrix * (-1/3) + 1

    # 以gama为阈值，将小于阈值的矩阵元素置为零
    gama = 0
    s_matrix[s_matrix < gama] = 0

    # 按行归一化为行和为1的矩阵
    row_sums = s_matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1e-10  # 避免除零错误
    s_matrix = s_matrix / row_sums
    # print(f"cmat = {s_matrix}")

    return s_matrix

'''
# 6维纹理特征
def v_feature_6(image):
    # 设定灰度级数为16
    levels = 16
    # 共生半径为4
    distances = [4]
    # 0、90、180、270四个方向
    angles = [0, np.pi / 2, np.pi, 3 * np.pi / 2]

    # 转换为灰度图像
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # 调整灰度级
    gray_image = np.floor(gray_image / (256 / levels)).astype(np.uint8)

    # 计算灰度共生矩阵
    glcm = skimage.feature.graycomatrix(gray_image, distances=distances, angles=angles, levels=levels, symmetric=True, normed=True)

    # 计算能量、对比度、能量密集度
    energy = skimage.feature.graycoprops(glcm, 'energy').mean()
    contrast = skimage.feature.graycoprops(glcm, 'contrast').mean()
    homogeneity = skimage.feature.graycoprops(glcm, 'homogeneity').mean()

    # 转换为HSV颜色空间
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hsv_gray = hsv_image[:, :, 2]
    hsv_gray = np.floor(hsv_gray / (256 / levels)).astype(np.uint8)

    # 计算HSV颜色空间的灰度共生矩阵
    hsv_glcm = skimage.feature.graycomatrix(hsv_gray, distances=distances, angles=angles, levels=levels, symmetric=True, normed=True)

    # 计算能量、对比度、能量密集度
    hsv_energy = skimage.feature.graycoprops(hsv_glcm, 'energy').mean()
    hsv_contrast = skimage.feature.graycoprops(hsv_glcm, 'contrast').mean()
    hsv_homogeneity = skimage.feature.graycoprops(hsv_glcm, 'homogeneity').mean()

    # 构成6维特征向量
    feature = [energy, contrast, homogeneity, hsv_energy, hsv_contrast, hsv_homogeneity]
    return np.array(feature)
'''

# 6维纹理特征
def v_feature_6(image):
    # 设定灰度级数为16
    levels = 16
    # 共生半径为4
    distances = [4]
    # 0、90、180、270四个方向
    angles = [0, np.pi / 2, np.pi, 3 * np.pi / 2]

    # 过滤掉纯白色像素
    non_white_mask = ~np.all(image == [255, 255, 255], axis=-1)
    non_white_image = image[non_white_mask]

    if non_white_image.size == 0:
        return np.zeros(6)

    # 计算非纯白色像素的行数和列数
    rows, cols = np.where(non_white_mask)
    min_row, max_row = np.min(rows), np.max(rows)
    min_col, max_col = np.min(cols), np.max(cols)
    cropped_image = image[min_row:max_row + 1, min_col:max_col + 1]

    # 转换为灰度图像
    gray_image = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)
    # 调整灰度级
    gray_image = np.floor(gray_image / (256 / levels)).astype(np.uint8)

    # 计算灰度共生矩阵
    glcm = skimage.feature.graycomatrix(gray_image, distances=distances, angles=angles, levels=levels, symmetric=True,
                                        normed=True)
    
    # # 取第一个方向的灰度共生矩阵用于显示
    # glcm_display = glcm[:, :, 0, 0]
    # # 归一化到0-255范围
    # glcm_display = cv2.normalize(glcm_display, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    # # 放大图像
    # scale_factor = 10  # 可根据需要调整放大倍数
    # new_width = int(glcm_display.shape[1] * scale_factor)
    # new_height = int(glcm_display.shape[0] * scale_factor)
    # glcm_display = cv2.resize(glcm_display, (new_width, new_height), interpolation=cv2.INTER_NEAREST)
    # # # 保存target
    # # if not os.path.exists('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\dark'):
    # #     os.makedirs('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\dark')
    # # target_path = os.path.join('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\dark', f'target_5.jpg')
    # # cv2.imwrite(target_path, glcm_display)  
    # # 显示灰度共生矩阵图像
    # cv2.imshow('Gray Level Co-occurrence Matrix', glcm_display)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    
    # 计算能量、对比度、能量密集度
    energy = skimage.feature.graycoprops(glcm, 'energy').mean()
    contrast = skimage.feature.graycoprops(glcm, 'contrast').mean()
    homogeneity = skimage.feature.graycoprops(glcm, 'homogeneity').mean()

    # 转换为HSV颜色空间
    hsv_image = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2HSV)
    hsv_gray = hsv_image[:, :, 2]
    hsv_gray = np.floor(hsv_gray / (256 / levels)).astype(np.uint8)

    # 计算HSV颜色空间的灰度共生矩阵
    hsv_glcm = skimage.feature.graycomatrix(hsv_gray, distances=distances, angles=angles, levels=levels, symmetric=True,
                                            normed=True)

    # 计算能量、对比度、能量密集度
    hsv_energy = skimage.feature.graycoprops(hsv_glcm, 'energy').mean()
    hsv_contrast = skimage.feature.graycoprops(hsv_glcm, 'contrast').mean()
    hsv_homogeneity = skimage.feature.graycoprops(hsv_glcm, 'homogeneity').mean()

    # 构成6维特征向量
    feature = [energy, contrast, homogeneity, hsv_energy, hsv_contrast, hsv_homogeneity]
    return np.array(feature)


# 纹理相似度矩阵
def s_mat_vien(features1, features2):
    # 计算特征向量之间的距离矩阵
    n1 = len(features1)
    n2 = len(features2)
    s_matrix = np.zeros((n1, n2))  # 初始化距离矩阵为全0的numpy数组

    for i, f1 in enumerate(features1):
        for j, f2 in enumerate(features2):
            distance = 0
            for ind in range(6):
                distance += np.abs(f1[ind] - f2[ind]) / (f1[ind] + f2[ind])
            s_matrix[i, j] = distance
        s_matrix[i]

    # similarity 1-s/6时全部大于0
    s_matrix = s_matrix * (-1) + 1 
    # 以gama为阈值，将小于阈值的矩阵元素置为零
    gama = 0
    s_matrix[s_matrix < gama] = 0

    # 数值差距还是蛮大的，直接按行归一化为行和为1的矩阵
    row_sums = s_matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1e-10  # 避免除零错误
    s_matrix = s_matrix / row_sums
    # print(f"vmat = {s_matrix}")

    return s_matrix


#3维位置特征
def p_feature_3(result):
    p_features = []
    _, det = result[0]
    num_targets = det.shape[0]

    # 计算每个目标框的中心点
    centers = []
    for i in range(num_targets):
        x0, y0, x1, y1, _, _ = det[i]
        # # 不是原图的xy，需要缩放才能匹配原图，但这里不影响计算
        # print(f"x0, y0, x1, y1 = {x0},{y0},{x1},{y1}\n")
        center_x = (x0 + x1) / 2
        center_y = (y0 + y1) / 2
        centers.append((center_x.item(), center_y.item()))

    for origin_index in range(num_targets):
        origin_x, origin_y = centers[origin_index]
        # 初始化每个区间的极径总和
        polar_features = [0] * 3

        for target_index in range(num_targets):
            if target_index == origin_index:
                continue

            target_x, target_y = centers[target_index]
            # 计算相对于原点的极坐标
            dx = target_x - origin_x
            dy = target_y - origin_y
            polar_angle = np.arctan2(dy, dx)
            if polar_angle < 0:
                polar_angle += 2 * np.pi
            # 计算极径
            polar_radius = np.sqrt(dx ** 2 + dy ** 2)

            # 确定目标所在的区间
            sector_index = int(polar_angle / (np.pi / 3 * 2))
            polar_features[sector_index] += polar_radius

        polar_features = polar_features / sum(polar_features)
        p_features.append(polar_features)
    # print(f"p_features = {p_features}")
    return p_features


#位置相似度矩阵  
def s_mat_pos(features1, features2):
    # 计算特征向量之间的距离矩阵
    n1 = len(features1)
    n2 = len(features2)
    s_matrix = np.zeros((n1, n2))  # 初始化距离矩阵为全0的numpy数组

    for i, f1 in enumerate(features1):
        for j, f2 in enumerate(features2):
            distance = np.sum(np.abs(f1 - f2))
            s_matrix[i, j] = distance

    # similarity = 1-s
    s_matrix = s_matrix * (-1) + 1

    # 以gama为阈值，将小于阈值的矩阵元素置为零
    gama = 0
    s_matrix[s_matrix < gama] = 0

    # 按行归一化为行和为1的矩阵
    row_sums = s_matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1e-10  # 避免除零错误
    s_matrix = s_matrix / row_sums
    # print(f"pmat = {s_matrix}")

    return s_matrix

#运用证据理论融合mat1、mat2
def D_S(mat1, mat2):
    dsmat = []
    rows = mat1.shape[0]
    cols = mat1.shape[1]
    for i in range(rows):
        k = 0
        new_row = []
        for j in range(cols):
            product_sum = 0
            for l in range(cols):
                if l != j:
                    product_sum += mat1[i, j] * mat2[i, l]
            k += product_sum
        for j in range(cols):
            new_value = (mat1[i, j] * mat2[i, j]) / k if k != 0 else 0
            new_row.append(new_value)
        dsmat.append(new_row)
    # print(f"dsmat = {dsmat}")
    return np.array(dsmat)


# 目标提取,image_data是一张图片
def process_data(image_data, result):
    c_features = []
    v_features = []
    # 处理 image_data 的检测结果
    path, im, im0s, _, _ = image_data
    for p, det in result:
        for *xyxy, _, _ in det:
            xyxy = [int(x) for x in xyxy]
            x1, y1, x2, y2 = xyxy
            # 裁剪目标
            target = im0s[y1:y2, x1:x2].copy()  # 创建副本，避免修改 im0s!

            # 从四个角落进行泛洪填充
            h, w = target.shape[:2]
            seed_points = [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]
            for seed_point in seed_points:
                target = flood_fill_improved(target, seed_point)
            # seed_point = (0, 0)
            # target = flood_fill_improved(target, seed_point)

            # 保存target
            # if not os.path.exists('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\4seed'):
            #     os.makedirs('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\4seed')
            # target_path = os.path.join('C:\\Users\\24105\\Desktop\\毕设\\毕业论文\\pics\\4seed', f'target_{len(c_features)}.jpg')
            # cv2.imwrite(target_path, target)   

            # #查看target
            # if target is not None and target.size > 0:
            #     # 创建窗口
            #     cv2.namedWindow("target", cv2.WINDOW_NORMAL)
            #     cv2.imshow("target", target)
            #     # 等待按键事件
            #     key = cv2.waitKey(0)
            #     # 关闭窗口
            #     cv2.destroyAllWindows()
            

            # 颜色矩特征提取
            feature = c_feature_30(target)
            c_features.append(feature)
            feature = v_feature_6(target)
            v_features.append(feature)

    return c_features, v_features

# 关联对求解det_sample/my_data/only2x1/pre_pairs.txt
def pairs(matrix):
    original_indices = []
    rows, cols = matrix.shape
    row_mask = np.ones(rows, dtype=bool)
    col_mask = np.ones(cols, dtype=bool)

    while np.any(row_mask) and np.any(col_mask):
        sub_matrix = matrix[row_mask][:, col_mask]
        max_value = np.max(sub_matrix)
        max_index = np.unravel_index(np.argmax(sub_matrix), sub_matrix.shape)

        original_row = np.where(row_mask)[0][max_index[0]]
        original_col = np.where(col_mask)[0][max_index[1]]

        original_indices.append((original_row, original_col))

        row_mask[original_row] = False
        col_mask[original_col] = False

    # print("关联对:", original_indices)
    
    return original_indices



# 概率重新分配
def redistribute(resa, resb, a_pairs):
    new_resa = []
    new_resb = []
    tag = False

    for p, det in resa:
        new_resa.append((p, det.clone()))
    for p, det in resb:
        new_resb.append((p, det.clone()))

    for idx_resa, idx_resb in a_pairs:
        p_resa, det_resa = new_resa[0]
        p_resb, det_resb = new_resb[0]
        conf_resa = det_resa[idx_resa, 4].item()
        conf_resb = det_resb[idx_resb, 4].item()
        cls_resa = det_resa[idx_resa, 5]
        cls_resb = det_resb[idx_resb, 5]

        if (conf_resa > 0.5 and conf_resb > 0.5):
            continue
        elif conf_resa > conf_resb + 0.1:
            det_resb[idx_resb, 5] = cls_resa
            tag = True
        elif conf_resb > conf_resa + 0.1:
            det_resa[idx_resa, 5] = cls_resb
            tag = True

    # 更新 new_resa 和 new_resb 中的 det
    new_resa[0] = (p_resa, det_resa)
    new_resb[0] = (p_resb, det_resb)

    # 提取关联对中的索引
    resa_indices, resb_indices = zip(*a_pairs) if a_pairs else ([], [])

    # 处理 resa 中需要删除的检测框
    p_resa, det_resa = new_resa[0]
    keep_mask_resa = torch.ones(len(det_resa), dtype=torch.bool, device=det_resa.device)
    for i in range(len(det_resa)):
        if i not in resa_indices and det_resa[i, 4].item() < 0.4:
            x0, y0, x1, y1, _, _ = det_resa[i].tolist()
            center_x = (x0 + x1) / 2
            center_y = (y0 + y1) / 2
            found = False
            for p_other, det_other in new_resb:
                for j in range(len(det_other)):
                    x0_other, y0_other, x1_other, y1_other, _, _ = det_other[j].tolist()
                    center_x_other = (x0_other + x1_other) / 2
                    center_y_other = (y0_other + y1_other) / 2
                    if abs(center_x - center_x_other) < 100 and abs(center_y - center_y_other) < 100:
                        found = True
                        break
                if found:
                    break
            if not found:
                keep_mask_resa[i] = False
    det_resa = det_resa[keep_mask_resa]
    new_resa[0] = (p_resa, det_resa)

    # 处理 resb 中需要删除的检测框
    p_resb, det_resb = new_resb[0]
    keep_mask_resb = torch.ones(len(det_resb), dtype=torch.bool, device=det_resb.device)
    for i in range(len(det_resb)):
        if i not in resb_indices and det_resb[i, 4].item() < 0.4:
            x0, y0, x1, y1, _, _ = det_resb[i].tolist()
            center_x = (x0 + x1) / 2
            center_y = (y0 + y1) / 2
            found = False
            for p_other, det_other in new_resa:
                for j in range(len(det_other)):
                    x0_other, y0_other, x1_other, y1_other, _, _ = det_other[j].tolist()
                    center_x_other = (x0_other + x1_other) / 2
                    center_y_other = (y0_other + y1_other) / 2
                    if abs(center_x - center_x_other) < 100 and abs(center_y - center_y_other) < 100:
                        found = True
                        break
                if found:
                    break
            if not found:
                keep_mask_resb[i] = False
    det_resb = det_resb[keep_mask_resb]
    new_resb[0] = (p_resb, det_resb)

    return new_resa, new_resb, tag



def associate(image1, image2, resulta, resultb):

    # 处理 image_data1、2 的检测结果
    c_features1, v_features1 = process_data(image1, resulta)
    c_features2, v_features2 = process_data(image2, resultb)
    p_features1 = p_feature_3(resulta)
    p_features2 = p_feature_3(resultb)
    # print(np.array(features1).shape)

    # 相似度矩阵
    s_m_color = s_mat_color(c_features1, c_features2)
    s_m_vien = s_mat_vien(v_features1,v_features2)
    s_m_pos = s_mat_pos(p_features1, p_features2)

    #D-S证据理论合并相似度矩阵
    ds_mat0 = D_S(s_m_color, s_m_vien)
    ds_mat = D_S(ds_mat0, s_m_pos)

    # 得到关联对
    associated_pairs = pairs(ds_mat0)
    try:
        with open('det_sample/my_data/only2x1/pre_pairs.txt', 'a') as file:
            result_str = " ".join([f"{pair[0]},{pair[1]}" for pair in associated_pairs])
            file.write(result_str + '\n')
    except FileNotFoundError:
        print("错误：未找到指定的文件路径或文件夹。")
    except Exception as e:
        print(f"错误：发生了未知错误：{e}")

    new_res1, new_res2, tag = redistribute(resulta, resultb, associated_pairs)

    return new_res1, new_res2, tag

if __name__ == "__main__":
    # 读取图像
    image = cv2.imread("E:\\targets\\50_13_2.jpg")
    # 转换颜色空间，因为OpenCV读取的图像是BGR格式，这里转换为RGB格式
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    features = c_feature_30(image)
    v_feature = v_feature_6(image)
    print(f"v_feature = {v_feature}")


    '''
    # 将30维特征重塑为一个二维数组
    feature_image = features.reshape(5, 6)

    # 将特征值归一化到0-255的范围
    feature_image = ((feature_image - np.min(feature_image)) / (np.max(feature_image) - np.min(feature_image))) * 255

    # 将数组转换为无符号8位整数类型
    feature_image = feature_image.astype(np.uint8)

    # 创建一个窗口并设置其大小
    cv2.namedWindow('Feature Image', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Feature Image', 400, 400)  # 设置窗口宽度为400，高度为400

    # 使用cv2.imshow显示特征图像
    cv2.imshow('Feature Image', feature_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    '''
    