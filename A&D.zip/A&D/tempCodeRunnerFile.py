 parser.add_argument('--source1', type=str, default=ROOT / 'det_sample/my_data/only2x1/sign1/images', help='第一个文件夹路径')
    par