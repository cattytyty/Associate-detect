import os
import subprocess


def calculate_iou(box1, box2):
    # 计算交集的坐标
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])

    # 计算交集的面积
    intersection_area = max(0, x2 - x1) * max(0, y2 - y1)

    # 计算两个框的面积
    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    # 计算并集的面积
    union_area = box1_area + box2_area - intersection_area

    # 计算IoU
    iou = intersection_area / union_area if union_area > 0 else 0

    return iou


# 运行 d_d_2.py
try:
    subprocess.run(['python', 'd_d_2.py'], check=True)
    print("d_d_2.py 运行成功")
except subprocess.CalledProcessError as e:
    print(f"运行 d_d_2.py 时出错: {e}")


# 预测结果文件路径
# 定义基础目录
base_dir = 'runs/detect'
# 初始化最大编号和对应的文件夹名
max_num = -1
max_dir = None
# 遍历基础目录下的所有文件夹
for dir_name in os.listdir(base_dir):
    if dir_name.startswith('exp'):
        try:
            # 提取编号
            num = int(dir_name[3:])
            if num > max_num:
                max_num = num
                max_dir = dir_name
        except ValueError:
            continue
# 构建最终的预测结果目录
if max_dir:
    prediction_dir = os.path.join(base_dir, max_dir, 'labels')
    print(f"预测结果目录为: {prediction_dir}")
else:
    print("未找到以 exp 开头的文件夹。")

# 标准标注文件路径
ground_truth_dir = 'det_sample/my_data/d_signs/sign1/labels'


# 类别名称
class_names = {
    0: 'benchi',
    1: 'bentian',
    2: 'bus',
    3: 'bwm',
    4: 'cybertruck',
    5: 'dazhon',
    6: 'fireengine',
    7: 'freight',
    8: 'freight0',
    9: 'greencar',
    10: 'jeep',
    11: 'joycart',
    12: 'lanbo',
    13: 'pickup',
    14: 'ypickup',
    15: 'yueye'
}

# IoU 阈值
iou_threshold = 0

# 初始化统计信息
true_positives = {i: 0 for i in range(len(class_names))}
false_positives = {i: 0 for i in range(len(class_names))}
false_negatives = {i: 0 for i in range(len(class_names))}
# 用于记录每个类别的ground truth数量
ground_truth_counts = {i: 0 for i in range(len(class_names))}

# 读取预测结果文件
for filename in os.listdir(prediction_dir):
    if filename.endswith('.txt'):
        prediction_file = os.path.join(prediction_dir, filename)
        ground_truth_file = os.path.join(ground_truth_dir, filename)

        # 读取预测结果
        with open(prediction_file, 'r') as f:
            predictions = [list(map(float, line.strip().split())) for line in f.readlines()]

        # 读取标准标注
        if os.path.exists(ground_truth_file):
            with open(ground_truth_file, 'r') as f:
                ground_truths = [list(map(float, line.strip().split())) for line in f.readlines()]
        else:
            ground_truths = []

        # 统计每个类别的ground truth数量
        for gt in ground_truths:
            gt_class = int(gt[0])
            ground_truth_counts[gt_class] += 1

        # 标记已匹配的标准标注
        matched_ground_truths = [False] * len(ground_truths)

        # 遍历预测结果
        for pred in predictions:
            pred_class = int(pred[0])
            pred_box = pred[1:]
            # 将YOLO格式的框转换为[x1, y1, x2, y2]格式
            pred_x_center, pred_y_center, pred_width, pred_height = pred_box
            pred_x1 = pred_x_center - pred_width / 2
            pred_y1 = pred_y_center - pred_height / 2
            pred_x2 = pred_x_center + pred_width / 2
            pred_y2 = pred_y_center + pred_height / 2
            pred_box = [pred_x1, pred_y1, pred_x2, pred_y2]
            found_match = False

            # 遍历标准标注
            for i, gt in enumerate(ground_truths):
                gt_class = int(gt[0])
                gt_box = gt[1:]
                # 将YOLO格式的框转换为[x1, y1, x2, y2]格式
                gt_x_center, gt_y_center, gt_width, gt_height = gt_box
                gt_x1 = gt_x_center - gt_width / 2
                gt_y1 = gt_y_center - gt_height / 2
                gt_x2 = gt_x_center + gt_width / 2
                gt_y2 = gt_y_center + gt_height / 2
                gt_box = [gt_x1, gt_y1, gt_x2, gt_y2]

                if pred_class == gt_class and not matched_ground_truths[i]:
                    iou = calculate_iou(pred_box, gt_box)
                    if iou >= iou_threshold:
                        true_positives[pred_class] += 1
                        matched_ground_truths[i] = True
                        found_match = True
                        break

            if not found_match:
                false_positives[pred_class] += 1

        # 计算false negatives
        for i, gt in enumerate(ground_truths):
            gt_class = int(gt[0])
            if not matched_ground_truths[i]:
                false_negatives[gt_class] += 1

# 输出统计信息
print("{:<10}{:<10}{:<10}{:<10}".format("类别", "数量", "Precision", "Recall"))
total_precision = 0
total_recall = 0
i = 0
for class_id, class_name in class_names.items():
    total_actual = ground_truth_counts[class_id]
    total_predicted = true_positives[class_id] + false_positives[class_id]
    precision = true_positives[class_id] / total_predicted if total_predicted > 0 else 0
    recall = true_positives[class_id] / total_actual if total_actual > 0 else 0
    if precision > 0.001:
        print("{:<10}{:<10}{:<10.4f}{:<10.4f}".format(class_name, total_actual, precision, recall))
        i += 1
        total_precision += precision
        total_recall += recall

# 计算平均 Precision 和 Recall
average_precision = total_precision / i
average_recall = total_recall / i
F1 = 2*average_precision*average_recall/(average_recall+average_precision)
# 输出平均 Precision 和 Recall
print(f"平均 Precision: {average_precision:.4f}")
print(f"平均 Recall: {average_recall:.4f}")
print(f"F1: {F1:.4f}")
    