# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Run YOLOv5 classification inference on images, videos, directories, globs, YouTube, webcam, streams, etc.

Usage - sources:
    $ python classify/predict.py --weights yolov5s-cls.pt --source 0                               # webcam
                                                                   img.jpg                         # image
                                                                   vid.mp4                         # video
                                                                   screen                          # screenshot
                                                                   path/                           # directory
                                                                   'path/*.jpg'                    # glob
                                                                   'https://youtu.be/Zgi9g1ksQHc'  # YouTube
                                                                   'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP stream

Usage - formats:
    $ python classify/predict.py --weights yolov5s-cls.pt                 # PyTorch
                                           yolov5s-cls.torchscript        # TorchScript
                                           yolov5s-cls.onnx               # ONNX Runtime or OpenCV DNN with --dnn
                                           yolov5s-cls_openvino_model     # OpenVINO
                                           yolov5s-cls.engine             # TensorRT
                                           yolov5s-cls.mlmodel            # CoreML (macOS-only)
                                           yolov5s-cls_saved_model        # TensorFlow SavedModel
                                           yolov5s-cls.pb                 # TensorFlow GraphDef
                                           yolov5s-cls.tflite             # TensorFlow Lite
                                           yolov5s-cls_edgetpu.tflite     # TensorFlow Edge TPU
                                           yolov5s-cls_paddle_model       # PaddlePaddle
"""

import argparse
import os
import platform
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

# 获取当前文件的绝对路径
FILE = Path(__file__).resolve()
# 获取 YOLOv5 的根目录
ROOT = FILE.parents[1]  # YOLOv5 root directory
# 将根目录添加到系统路径中，以便后续导入模块
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
# 将根目录转换为相对路径
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

# 从不同模块导入所需的类和函数
from models.common import DetectMultiBackend
from utils.augmentations import classify_transforms
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (LOGGER, Profile, check_file, check_img_size, check_imshow, check_requirements, colorstr, cv2,
                           increment_path, print_args, strip_optimizer)
from utils.plots import Annotator
from utils.torch_utils import select_device, smart_inference_mode

# 使用智能推理模式装饰器，确保推理过程的正确性和效率
@smart_inference_mode()
def run(
        weights=ROOT / 'yolov5s-cls.pt',  # 模型权重文件的路径
        source=ROOT / 'data/images',  # 推理数据的来源，可以是文件、目录、URL、截图、摄像头等
        data=ROOT / 'data/coco128.yaml',  # 数据集配置文件的路径
        imgsz=(224, 224),  # 推理时输入图像的尺寸 (高度, 宽度)
        device='',  # 推理使用的设备，如 GPU 编号或 'cpu'
        view_img=False,  # 是否显示推理结果
        save_txt=False,  # 是否将推理结果保存到文本文件
        nosave=False,  # 是否不保存图像或视频结果
        augment=False,  # 是否使用增强推理
        visualize=False,  # 是否可视化特征
        update=False,  # 是否更新所有模型
        project=ROOT / 'runs/predict-cls',  # 保存推理结果的项目目录
        name='exp',  # 保存推理结果的子目录名称
        exist_ok=False,  # 若项目/名称已存在是否继续，不进行递增处理
        half=False,  # 是否使用 FP16 半精度推理
        dnn=False,  # 是否使用 OpenCV DNN 进行 ONNX 推理
        vid_stride=1,  # 视频帧的采样步长
):
    # 将源路径转换为字符串
    source = str(source)
    # 判断是否保存推理图像
    save_img = not nosave and not source.endswith('.txt')  # save inference images
    # 判断源是否为图像或视频文件
    is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)
    # 判断源是否为 URL
    is_url = source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))
    # 判断源是否为摄像头、文本文件或 URL 但不是文件
    webcam = source.isnumeric() or source.endswith('.txt') or (is_url and not is_file)
    # 判断源是否为截图
    screenshot = source.lower().startswith('screen')
    # 若源为 URL 且是文件，则下载文件
    if is_url and is_file:
        source = check_file(source)  # download

    # 处理保存目录
    # Directories
    # 生成保存结果的目录，若目录已存在则递增目录名称
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    # 创建保存标签或图像的目录
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # 加载模型
    # Load model
    # 选择推理设备
    device = select_device(device)
    # 加载多后端模型，支持多种格式的模型
    model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data, fp16=half)
    # 获取模型的步长、类别名称和是否为 PyTorch 模型的标志
    stride, names, pt = model.stride, model.names, model.pt
    # 检查输入图像的尺寸是否符合模型要求
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # 数据加载器
    # Dataloader
    # 批量大小初始化为 1
    bs = 1  # batch_size
    if webcam:
        # 检查是否可以显示图像
        view_img = check_imshow(warn=True)
        # 加载摄像头或流数据
        dataset = LoadStreams(source, img_size=imgsz, transforms=classify_transforms(imgsz[0]), vid_stride=vid_stride)
        # 更新批量大小为数据集的长度
        bs = len(dataset)
    elif screenshot:
        # 加载截图数据
        dataset = LoadScreenshots(source, img_size=imgsz, stride=stride, auto=pt)
    else:
        # 加载图像或视频数据
        dataset = LoadImages(source, img_size=imgsz, transforms=classify_transforms(imgsz[0]), vid_stride=vid_stride)
    # 初始化视频路径和视频写入器列表
    vid_path, vid_writer = [None] * bs, [None] * bs

    # 运行推理
    # Run inference
    # 对模型进行预热，确保推理速度稳定
    model.warmup(imgsz=(1 if pt else bs, 3, *imgsz))  # warmup
    # 初始化已处理的样本数、窗口列表和时间记录器
    seen, windows, dt = 0, [], (Profile(), Profile(), Profile())
    # 遍历数据集进行推理
    for path, im, im0s, vid_cap, s in dataset:
        # 数据预处理阶段
        with dt[0]:
            # 将图像数据转换为张量并移动到指定设备
            im = torch.Tensor(im).to(model.device)
            # 根据模型是否使用半精度，将图像数据转换为相应的精度
            im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
            # 若图像数据维度为 3，则添加一个批量维度
            if len(im.shape) == 3:
                im = im[None]  # expand for batch dim

        # 推理阶段
        # Inference
        with dt[1]:
            # 调用模型进行推理
            results = model(im)

        # 后处理阶段
        # Post-process
        with dt[2]:
            # 对模型输出进行 softmax 操作，得到每个类别的概率
            pred = F.softmax(results, dim=1)  # probabilities

        # 处理预测结果
        # Process predictions
        # 遍历每个样本的预测结果
        for i, prob in enumerate(pred):  # per image
            # 增加已处理的样本数
            seen += 1
            if webcam:  # 若为批量推理（如摄像头数据）
                # 获取当前样本的路径、原始图像和帧编号
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f'{i}: '
            else:
                # 获取当前样本的路径、原始图像和帧编号
                p, im0, frame = path, im0s.copy(), getattr(dataset, 'frame', 0)

            # 将路径转换为 Path 对象
            p = Path(p)  # to Path
            # 生成保存图像的路径
            save_path = str(save_dir / p.name)  # im.jpg
            # 生成保存标签的路径
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # im.txt

            # 打印输入图像的尺寸信息
            s += '%gx%g ' % im.shape[2:]  # print string
            # 创建一个注释器对象，用于在图像上绘制信息
            annotator = Annotator(im0, example=str(names), pil=True)

            # 打印预测结果
            # Print results
            # 获取概率最高的前 5 个类别的索引
            top5i = prob.argsort(0, descending=True)[:5].tolist()  # top 5 indices
            # 打印前 5 个类别的名称和概率
            s += f"{', '.join(f'{names[j]} {prob[j]:.2f}' for j in top5i)}, "

            # 写入预测结果
            # Write results
            # 生成包含前 5 个类别的概率和名称的文本
            text = '\n'.join(f'{prob[j]:.2f} {names[j]}' for j in top5i)
            if save_img or view_img:  # 若需要保存图像或显示图像
                # 在图像上添加文本注释
                annotator.text((32, 32), text, txt_color=(255, 255, 255))
            if save_txt:  # 若需要保存标签到文本文件
                # 打开文本文件并写入预测结果
                with open(f'{txt_path}.txt', 'a') as f:
                    f.write(text + '\n')

            # 显示推理结果
            # Stream results
            # 获取注释后的图像
            im0 = annotator.result()
            if view_img:
                if platform.system() == 'Linux' and p not in windows:
                    # 在 Linux 系统上创建可调整大小的窗口
                    windows.append(p)
                    cv2.namedWindow(str(p), cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)  # allow window resize (Linux)
                    cv2.resizeWindow(str(p), im0.shape[1], im0.shape[0])
                # 显示图像
                cv2.imshow(str(p), im0)
                # 等待 1 毫秒
                cv2.waitKey(1)  # 1 millisecond

            # 保存推理结果（带检测结果的图像）
            # Save results (image with detections)
            if save_img:
                if dataset.mode == 'image':
                    # 保存图像
                    cv2.imwrite(save_path, im0)
                else:  # 'video' or 'stream'
                    if vid_path[i] != save_path:  # 若为新视频
                        # 更新视频路径
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            # 释放之前的视频写入器
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # 若为视频文件
                            # 获取视频的帧率、宽度和高度
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # 若为流数据
                            # 默认帧率、宽度和高度
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        # 强制保存的视频文件后缀为 .mp4
                        save_path = str(Path(save_path).with_suffix('.mp4'))  # force *.mp4 suffix on results videos
                        # 创建新的视频写入器
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
                    # 写入视频帧
                    vid_writer[i].write(im0)

        # 打印推理时间（仅推理阶段）
        LOGGER.info(f"{s}{dt[1].dt * 1E3:.1f}ms")

    # 打印最终结果
    # Print results
    # 计算每个样本的预处理、推理和后处理时间
    t = tuple(x.t / seen * 1E3 for x in dt)  # speeds per image
    LOGGER.info(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {(1, 3, *imgsz)}' % t)
    if save_txt or save_img:
        # 若保存了标签或图像，打印保存信息
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")
    if update:
        # 若需要更新模型，去除优化器状态
        strip_optimizer(weights[0])  # update model (to fix SourceChangeWarning)

# 解析命令行参数
def parse_opt():
    # 创建参数解析器
    parser = argparse.ArgumentParser()
    # 添加模型权重文件路径参数
    parser.add_argument('--weights', nargs='+', type=str, default=ROOT / 'yolov5s-cls.pt', help='model path(s)')
    # 添加推理数据来源参数
    parser.add_argument('--source', type=str, default=ROOT / 'data/images', help='file/dir/URL/glob/screen/0(webcam)')
    # 添加数据集配置文件路径参数
    parser.add_argument('--data', type=str, default=ROOT / 'data/coco128.yaml', help='(optional) dataset.yaml path')
    # 添加推理输入图像尺寸参数
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[224], help='inference size h,w')
    # 添加推理设备参数
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    # 添加是否显示推理结果参数
    parser.add_argument('--view-img', action='store_true', help='show results')
    # 添加是否保存推理结果到文本文件参数
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    # 添加是否不保存图像或视频结果参数
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    # 添加是否使用增强推理参数
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    # 添加是否可视化特征参数
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    # 添加是否更新所有模型参数
    parser.add_argument('--update', action='store_true', help='update all models')
    # 添加保存推理结果的项目目录参数
    parser.add_argument('--project', default=ROOT / 'runs/predict-cls', help='save results to project/name')
    # 添加保存推理结果的子目录名称参数
    parser.add_argument('--name', default='exp', help='save results to project/name')
    # 添加若项目/名称已存在是否继续，不进行递增处理参数
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    # 添加是否使用 FP16 半精度推理参数
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    # 添加是否使用 OpenCV DNN 进行 ONNX 推理参数
    parser.add_argument('--dnn', action='store_true', help='use OpenCV DNN for ONNX inference')
    # 添加视频帧的采样步长参数
    parser.add_argument('--vid-stride', type=int, default=1, help='video frame-rate stride')
    # 解析命令行参数
    opt = parser.parse_args()
    # 若输入图像尺寸只指定了一个值，则扩展为两个相同的值
    opt.imgsz *= 2 if len(opt.imgsz) == 1 else 1  # expand
    # 打印解析后的参数
    print_args(vars(opt))
    return opt

# 主函数
def main(opt):
    # 检查所需的依赖库是否安装
    check_requirements(exclude=('tensorboard', 'thop'))
    # 调用 run 函数进行推理
    run(**vars(opt))

# 程序入口
if __name__ == "__main__":
    # 解析命令行参数
    opt = parse_opt()
    # 调用主函数
    main(opt)